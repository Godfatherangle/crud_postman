const express = require('express');
const router = express.Router();
const m1 = require('../models/modell');

router.get('/', async (req, res) => {
  try {
    const users = await m1.find();
    res.json(users);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const user = await m1.findById(req.params.id);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    res.json(user);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});


router.post('/', async(req,res) => {
    const m2 = new m1({
        name : req.body.name,
        age : req.body.age,
        addresses : req.body.addresses
    })

    try{
        const a1 =  await m2.save() 
        res.json(a1)
    }catch(err){
        res.send('Error')
    }
})

router.patch('/:id', async(req, res)=> {
    try{
        const p1 = await m1.findById(req.params.id)
        p1.name = req.body.name
        res.json(p1)
    
    }
    catch(err){
        res.send('error patch')
    
    }
    
    })
    
    
    router.put('/:id', async(req, res)=> {
        try{
            const p1 = await m1.findById(req.params.id)
            p1.name = req.body.name
            p1.age = req.body.age
            p1.addresses = req.body.addresses
            res.json(p1)
        
        }
        catch(err){
            res.send('error patch')
        
        }
        
        })
    

        router.delete('/:id',async (req, res) => {
            try{
                const del = await m1.findByIdAndDelete(req.params.id)
                res.json(del)
            }
            catch(err){
                  res.send('del error')
            }
        })

module.exports = router;
