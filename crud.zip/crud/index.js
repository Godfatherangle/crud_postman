const express = require('express');
const mongoose = require('mongoose');
const url = 'mongodb://localhost/m1'
const app = express();
const port = 1000;


mongoose.connect('mongodb://localhost/m1', { useNewUrlParser: true, useUnifiedTopology: true });
const con = mongoose.connection

con.on('open', () => {
    console.log("connection open")
})

app.use(express.json())

const plRouter = require('./routes/route')
app.use('/aliens',plRouter)


app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});

